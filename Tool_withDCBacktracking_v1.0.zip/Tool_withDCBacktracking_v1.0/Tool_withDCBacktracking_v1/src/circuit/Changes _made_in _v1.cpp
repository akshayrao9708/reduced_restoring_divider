Changes made in v1.0

1. Added class for multiplexer in circuit.h file 
2. Added vector<Multiplexer> foundMuxs member in circuit.h file 